<?php 
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'comment';
$modulename = '评论';
$introduce = '评论模块';
$author = 'phpcms team';
$authorsite = 'http://www.phpcms.cn';
$authoremail = '';
?>