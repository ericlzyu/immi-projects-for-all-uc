<table cellpadding="2" cellspacing="1" width="98%">
	<tr> 
      <td>默认值</td>
      <td><input type="text" name="setting[defaultvalue]" value="" size="40" class="input-text"></td>
    </tr>
</table>