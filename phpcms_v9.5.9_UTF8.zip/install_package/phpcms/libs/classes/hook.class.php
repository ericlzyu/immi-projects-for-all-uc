<?php 
class hook {
	 static function glogal_header() {} 
	 static function glogal_footer() {}
	 static function glogal_menu() {}
	 static function admin_content_init() {}
	 static function admin_top_left_menu() {}
}
?>