<?php

return array (
	'default' => array (
		'hostname' => 'localhost',
		'port' => 3306,
		'database' => 'phpcmsv9',
		'username' => '',
		'password' => '',
		'tablepre' => 'v9_',
		'charset' => 'utf8',
		'type' => 'mysql',
		'debug' => true,
		'pconnect' => 0,
		'autoconnect' => 0
		),
);

?>