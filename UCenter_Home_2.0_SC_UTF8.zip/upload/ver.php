<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: common.php 12271 2009-05-31 06:14:11Z xupeng $
*/

define('X_VER', '2.0');
define('X_RELEASE', '20100416');

?>