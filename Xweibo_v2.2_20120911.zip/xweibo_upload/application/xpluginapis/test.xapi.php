<?php

class test_xapi {

	function test_xapi(){
		
	}
	
	//用于检查双方APPKEY是否相同的方法
	function default_api($ckStr){
		
	}
}
