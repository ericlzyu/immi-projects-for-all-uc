<?php
/**
 * OAUTH2_AUTHRIZE_TYPE为2或者3的时候，获取Access token的方法
 * 此部分分离出来，用于给定制版进行定制开发
 * @author yaoying
 * @version $Id: oauth2_outer_get_access_token.func.php 18379 2012-07-10 07:10:50Z yaoying $
 * @return RST_Array
 */
function oauth2_outer_get_access_token(){
	
	if(2 == OAUTH2_AUTHRIZE_TYPE){
		//编写从外部（新浪微博API）、但redirect_uri不是xweibo地址获取access token的方法
		return DR('xweibo/xwb.getAccessToken', false, V('g:code'), array('redirect_uri'=>OAUTH2_PLATFORM_CALLBACK_URL), true);
		
	}elseif(3 == OAUTH2_AUTHRIZE_TYPE){
		//编写从外部（非新浪微博API）获取access token的方法
		//获取后，必须手动设置一下token：
		//DS('xweibo/xwb.setToken', false, 3, 'ACCESS_TOKEN', 'REFRESH_TOKEN');
		
		return RST(false, 555555, 'NOT_DEFINED');
	}else{
		return RST(false, 555555, 'NOT_DEFINED');
	}
	
}