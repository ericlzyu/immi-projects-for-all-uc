<?php
/**
 * @file			get_reg_url_func.php
 * @CopyRight		(C)1996-2099 SINA Inc.
 * @Project			Xweibo
 * @Author			heli <heli1@staff.sina.com.cn>
 * @Create Date:	2010-11-15
 * @Modified By:	heli/2010-11-15
 * @Brief			获取注册url函数-Xweibo
 */

function get_reg_url()
{
	return 'http://weibo.com/signup/signup.php';
}
