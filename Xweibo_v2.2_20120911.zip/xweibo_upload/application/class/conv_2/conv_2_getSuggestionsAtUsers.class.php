<?php
/**
 * 搜索微博文章
 * @author yaoying
 * @version $Id: conv_2_getSuggestionsAtUsers.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_getSuggestionsAtUsers extends conv_2_base{
	
	/**
	 * 
	 * @param array $data
	 * @return array
	 */
	function convert($data){
		foreach($data as $k => $row){
			if(!isset($row['remark'])){
				$data[$k]['remark'] = '';
			}
			$data[$k]['nickname'] = $row['screen_name'];
		}
		return $data;
	}
	
}