<?php
/**
 * （通用）仅返回statuses里面的内容
 * @author yaoying
 * @version $Id: conv_2_common_only_statuses.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_common_only_statuses extends conv_2_base{
	
	function convert($data){
		return $data['statuses'];
	}
	
}