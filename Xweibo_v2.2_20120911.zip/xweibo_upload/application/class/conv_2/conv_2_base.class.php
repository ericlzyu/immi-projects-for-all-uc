<?php
/**
 * （通用）OAuth 2.0数据转换到OAuth 1.0的基类
 * @author yaoying
 * @version $Id: conv_2_base.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
class conv_2_base{
	
	/**
	 * 
	 * @param array $data
	 * @param array $param 参数。可选
	 * @return array
	 */
	function convert($data = array(), $param = array()){
		
	}
	
}