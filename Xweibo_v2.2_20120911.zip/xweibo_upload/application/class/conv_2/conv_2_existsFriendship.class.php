<?php
/**
 * 将getFriendship转换为existsFriendship
 * @author yaoying
 * @version $Id: conv_2_existsFriendship.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_existsFriendship extends conv_2_base{
	
	/**
	 * 
	 * @param array $data
	 * @return array
	 */
	function convert($data){
		$result = array('friends'=>false);
		if(isset($data['source']['following'])){
			$result['friends'] = $data['source']['following'];
		}
		return $result;
	}
	
}