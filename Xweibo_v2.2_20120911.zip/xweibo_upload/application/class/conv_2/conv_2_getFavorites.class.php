<?php
/**
 * @see http://open.weibo.com/wiki/2/favorites
 * @see http://open.weibo.com/wiki/Favorites
 * @author yaoying
 * @version $Id: conv_2_getFavorites.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_getFavorites extends conv_2_base{
	
	function convert($data){
		$new = array();
		foreach($data['favorites'] as $row){
			$new[] = $row['status'];
		}
		return $new;
	}
	
}