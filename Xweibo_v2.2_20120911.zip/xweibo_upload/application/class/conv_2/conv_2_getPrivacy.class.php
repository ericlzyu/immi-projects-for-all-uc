<?php
/**
 * @see http://open.weibo.com/wiki/Account/get_privacy
 * @see http://open.weibo.com/wiki/2/account/get_privacy
 * @author yaoying
 * @version $Id: conv_2_getPrivacy.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_getPrivacy extends conv_2_base{
	
	function convert($data){
		$data['dm'] = $data['message'];
		$data['real_name'] = $data['realname'];
		return $data;
	}
	
}