<?php
/**
 * （通用）仅返回指定body里面的内容
 * @author yaoying
 * @version $Id: conv_2_common_only_body.class.php 18380 2012-07-10 07:30:20Z yaoying $
 *
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_common_only_body extends conv_2_base{
	
	/**
	 * 
	 * @param array $data
	 * @param array $param 参数，必填key有：
	 * [string] body 要提取的body
	 * @return array
	 */
	function convert($data, $param){
		if(!isset($param['body']) || !isset($data[$param['body']])){
			return array();
		}else{
			return $data[$param['body']];
		}
	}
	
}