<?php
/**
 * 表情代码转换
 * @author yaoying
 * @version $Id: conv_2_emotions.class.php 18380 2012-07-10 07:30:20Z yaoying $
 */
if (!defined('XWB_SERVER_ENV_TYPE')) {
	exit('ACCESS DENIED');
}
class conv_2_emotions extends conv_2_base{
	
	/**
	 * @param array $data
	 * @return array
	 */
	function convert($data){
		foreach($data as $k => $v){
			$data[$k]['is_hot'] = $v['hot'];
			$data[$k]['is_common'] = $v['common'];
			$data[$k]['order_number'] = intval($k);
		}
		return $data;
	}
	
}
