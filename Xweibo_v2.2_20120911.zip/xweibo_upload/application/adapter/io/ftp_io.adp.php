<?php
/**************************************************
*  Created:  2010-06-08
*
*  FTP操作
*
*  @Xweibo (C)1996-2099 SINA Inc.
*  @Author xionghui <xionghui1@staff.sina.com.cn>
*
***************************************************/

class ftp_io
{
	function ftp_io() {

	}

	function adp_init($config=array()) {

	}

	function write($file,$contents,$is_append=false) {
		
	}

	function read($file) {
		
	}

	function delete($key) {
		
	}
	
	function mkdir($dirs) {
		
	}
	
	function rmdir($dir){
	}
}
?>