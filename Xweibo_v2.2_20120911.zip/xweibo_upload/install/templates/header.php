<div id="header">
	<span><!--<a href="http://x.weibo.com/bbs" target="_blank"><?php //echo $_LANG['feedback'];?></a> | --><a href="http://x.weibo.com/help.php" target="_blank"><?php echo $_LANG['help'];?></a></span>
	<h1 class="logo">Xweibo</h1>
</div>
