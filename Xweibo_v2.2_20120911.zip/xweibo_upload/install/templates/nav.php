<div class="step-nav">
              <ul class="clear">
                <li class="one"><span>1.<?php echo $_LANG['env_check'];?></span></li>
                <li class="two"><span>2.<?php echo $_LANG['site_info'];?></span></li>
                <li class="three"><span>3.<?php echo $_LANG['system_config'];?></span></li>
                <li class="four"><span>4.<?php echo $_LANG['done'];?></span><img src="img/true1.gif" /></li>
              </ul>
              <div class="progress">
                <div class="progress-inner"><span class="l"></span><span class="arrow"></span><span class="r"></span></div>
              </div>
            </div>